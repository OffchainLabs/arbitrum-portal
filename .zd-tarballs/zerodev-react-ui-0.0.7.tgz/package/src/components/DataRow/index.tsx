import type { ReactNode } from 'react'

import { cn } from '../../utils/common'
import { Icon } from '../Icon'
import { Text } from '../Text'
import { Tooltip } from '../Tooltip'

export interface DataRowProps {
  /** Label rendered on the left (e.g., "Max slippage"). */
  label: string
  /** Value rendered on the right. Accepts a string (wrapped in `Text`) or an
   * arbitrary ReactNode (rendered verbatim). */
  value: ReactNode
  /** Renders a small info icon (14×14, greyScale/50) between the label and
   * the value. */
  info?: boolean
  /** Handler for the info icon; when supplied, the icon becomes a keyboard-
   * accessible button. Requires `info` to be true. */
  onInfoClick?: () => void
  /** Tooltip text shown on hover / focus over the info icon. Rendered via
   * `Tooltip` (Radix), so it collides / portals correctly. Ignored when
   * `info` is false. */
  infoTooltip?: string
  /** Content rendered inside the value group, before the value. Typically a
   * small decorative or status icon (e.g. warning). */
  leading?: ReactNode
  /** Content rendered inside the value group, after the value. Typically a
   * chevron or trailing icon. */
  trailing?: ReactNode
  /** `'default'` for a plain inline row; `'warning'` for the orange-tinted
   * card treatment (Figma "Minimum deposit") — tinted card and orange info
   * icon, default-ink text. */
  variant?: 'default' | 'warning'
  className?: string
}

export function DataRow({
  label,
  value,
  info,
  onInfoClick,
  infoTooltip,
  leading,
  trailing,
  variant = 'default',
  className,
}: DataRowProps) {
  // Design review (Min deposit): label/value read in the default ink even on
  // the warning card — only the card tint and info icon are orange.
  const isWarning = variant === 'warning'

  return (
    <div
      className={cn(
        'zd:relative zd:flex zd:w-full zd:items-center',
        isWarning
          ? // Warning: card treatment — 14px radius, border, backdrop blur,
            // 10% orange tint, universal inner shadow, tighter row padding.
            [
              'zd:gap-2 zd:overflow-hidden zd:rounded-[14px] zd:border-[0.3px] zd:border-offWhite zd:px-4 zd:py-2 zd:backdrop-blur-[15px]',
              'zd:shadow-[inset_0_-4px_4px_0_rgba(255,255,255,0.1),inset_0_3px_4px_0_rgba(0,0,0,0.02)]',
            ]
          : // Default: plain inline row with a 4px gap between children and
            // 4px vertical padding.
            'zd:gap-1 zd:py-1',
        className,
      )}
      style={
        isWarning ? { backgroundColor: 'rgba(242, 123, 62, 0.1)' } : undefined
      }
    >
      <Text className="zd:whitespace-nowrap">{label}</Text>
      {info && (
        <Tooltip content={infoTooltip}>
          {onInfoClick ? (
            <button
              type="button"
              onClick={onInfoClick}
              aria-label={
                infoTooltip
                  ? `${label} — ${infoTooltip}`
                  : `${label} — more info`
              }
              className="zd:flex zd:items-center zd:justify-center zd:cursor-pointer"
              data-testid="data-row-info"
            >
              <Icon
                name={isWarning ? 'infoOutline' : 'info'}
                className={cn(
                  'zd:w-3.5 zd:h-3.5',
                  // Warning rows use the thin outline glyph at half opacity
                  // (Figma 20002:36053) instead of the filled disc.
                  isWarning
                    ? 'zd:text-solarOrange zd:opacity-50'
                    : 'zd:text-greyScale/50',
                )}
                aria-hidden
              />
            </button>
          ) : (
            // Real DOM element so Radix's `Tooltip` trigger (via `asChild`)
            // can attach hover / focus handlers and wire `aria-describedby`
            // to its content — no manual aria-label needed on the span.
            // Focusable only when there's a tooltip; otherwise this is a
            // decorative info icon and shouldn't land in the tab order.
            <span
              tabIndex={infoTooltip ? 0 : -1}
              className={cn(
                'zd:inline-flex zd:items-center zd:justify-center',
                infoTooltip && 'zd:cursor-help zd:outline-none',
              )}
              data-testid="data-row-info"
            >
              <Icon
                name={isWarning ? 'infoOutline' : 'info'}
                className={cn(
                  'zd:w-3.5 zd:h-3.5',
                  // Warning rows use the thin outline glyph at half opacity
                  // (Figma 20002:36053) instead of the filled disc.
                  isWarning
                    ? 'zd:text-solarOrange zd:opacity-50'
                    : 'zd:text-greyScale/50',
                )}
                aria-hidden
              />
            </span>
          )}
        </Tooltip>
      )}
      {/* Spacer pushes the value to the right end. min-w-0 so the label and
          value can shrink independently if the container is narrow. */}
      <div className="zd:min-w-0 zd:flex-1" />
      <div
        className="zd:flex zd:items-center zd:gap-[5px]"
        data-testid="data-row-value"
      >
        {leading}
        {typeof value === 'string' ? (
          <Text className="zd:whitespace-nowrap">{value}</Text>
        ) : (
          value
        )}
        {trailing}
      </div>
    </div>
  )
}

export interface DataRowSkeletonProps {
  /** Optional label to render as-is on the left; when omitted a pulse
   * placeholder is drawn in its place. */
  label?: string
  className?: string
}

export function DataRowSkeleton({ label, className }: DataRowSkeletonProps) {
  return (
    <div
      className={cn(
        'zd:flex zd:flex-row zd:items-center zd:justify-between zd:py-1',
        className,
      )}
    >
      {label ? (
        <Text>{label}</Text>
      ) : (
        <div className="zd:w-24 zd:h-3 zd:rounded-lg zd:bg-greyScale/15 zd:animate-skel-pulse" />
      )}
      <div className="zd:w-24 zd:h-3 zd:rounded-lg zd:bg-greyScale/15 zd:animate-skel-pulse" />
    </div>
  )
}
