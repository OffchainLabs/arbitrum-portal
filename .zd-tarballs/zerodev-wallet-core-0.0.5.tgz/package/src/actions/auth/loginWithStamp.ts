import { canonicalizeEx } from 'json-canonicalize'
import type { Client } from '../../client/types.js'
import type { Stamp } from '../../stampers/types.js'
import type { StamperType } from '../../types/session.js'

export type LoginWithStampParameters = {
  /** The project ID for the request */
  projectId: string
  /** The organization ID for the request */
  organizationId: string
  /** The encoded public key for the request */
  targetPublicKey: string
  /** The stamper type for the request */
  stampWith?: StamperType
}

export type LoginWithStampReturnType = {
  /** The session */
  session: string
}

/**
 * Logs in a user with a stamp
 *
 * @param client - The ZeroDev Wallet client
 * @param params - The parameters for login with a stamp
 * @returns The login result
 *
 * @example
 * ```ts
 * const result = await loginWithStamp(client, {
 *   organizationId: 'org_456',
 *   projectId: 'proj_456',
 *   targetPublicKey: 'encodedPublicKey',
 * });
 * ```
 */
export async function loginWithStamp(
  client: Client,
  params: LoginWithStampParameters,
): Promise<LoginWithStampReturnType> {
  const { projectId, targetPublicKey, organizationId, stampWith } = params

  const timestampMs = Date.now()
  const timestampMsString = timestampMs.toString()
  const timestampIso = new Date(timestampMs).toISOString()

  const stampPayload = canonicalizeEx({
    organizationId,
    parameters: {
      publicKey: targetPublicKey,
    },
    timestampMs: timestampMsString,
    type: 'ACTIVITY_TYPE_STAMP_LOGIN',
  })
  let stamp: Stamp
  if (stampWith === 'apiKey') {
    stamp = await client.apiKeyStamper.stamp(stampPayload)
  } else if (stampWith === 'passkey') {
    stamp = await client.passkeyStamper.stamp(stampPayload)
  } else {
    stamp = await client.apiKeyStamper.stamp(stampPayload)
  }

  return client.request({
    path: `${projectId}/auth/login/stamp`,
    method: 'POST',
    // The sub-org id is intentionally not sent: the backend derives it from
    // the stamped credential. `organizationId` (the parent org) is only
    // signed into `stampPayload` above so the stamp matches the body the
    // backend relays to Turnkey — it is not part of the wire request.
    body: {
      targetPublicKey,
      timestamp: timestampIso,
      stamp,
    },
  })
}
