import type { Client } from '../../client/types.js'

export type GetAuthenticatorsParameters = {
  /** The sub-organization ID to query authenticators for */
  subOrganizationId: string
  /** The project ID for the request */
  projectId: string
  /** The session token for authorization */
  token: string
}

/** An OAuth authenticator linked to the user */
export type OAuthAuthenticator = {
  provider?: string
  clientId?: string
  subject?: string
  [key: string]: unknown
}

/** A passkey (WebAuthn) authenticator */
export type PasskeyAuthenticator = {
  rpId?: string
  publicKey?: string
  credentialId?: string
  [key: string]: unknown
}

/** An email contact linked to the user */
export type EmailContact = {
  email?: string
  [key: string]: unknown
}

/** An API key authenticator */
export type ApiKeyAuthenticator = {
  apiKey?: string
  [key: string]: unknown
}

/** A temporary session key registered for an authenticated SDK session. */
export type SessionKeyAuthenticator = {
  /** Current backend wire casing (the Go model has no JSON tags). */
  ApiKey?: string
  KeyType?: string
  ExpiresAt?: string
  TurnkeyId?: string
  /** Forward-compatible casing if the backend adds JSON tags. */
  apiKey?: string
  keyType?: string
  expiresAt?: string
  turnkeyId?: string
  [key: string]: unknown
}

export type GetAuthenticatorsReturnType = {
  /** OAuth providers linked to the user (null if none) */
  oauths: OAuthAuthenticator[] | null
  /** Passkey authenticators registered for the user (null if none) */
  passkeys: PasskeyAuthenticator[] | null
  /** Email contacts associated with the user (null if none) */
  emailContacts: EmailContact[] | null
  /** API keys associated with the user (null if none) */
  apiKeys: ApiKeyAuthenticator[] | null
  /** Temporary session keys associated with the user (null if none) */
  sessionKeys: SessionKeyAuthenticator[] | null
}

/**
 * Fetches all authenticators (oauths, passkeys, emailContacts, apiKeys,
 * sessionKeys) for
 * the authenticated user within the given project/sub-organization.
 *
 * Corresponds to `GET /api/v1/{projectId}/authenticators`.
 *
 * @param client - The ZeroDev Wallet client
 * @param params - The parameters for the authenticators request
 * @returns The user's authenticators grouped by type
 *
 * @example
 * ```ts
 * const authenticators = await getAuthenticators(client, {
 *   subOrganizationId: 'suborg_123',
 *   projectId: 'proj_456',
 *   token: 'session_token_abc',
 * });
 * console.log(authenticators.oauths, authenticators.passkeys);
 * ```
 */
export async function getAuthenticators(
  client: Client,
  params: GetAuthenticatorsParameters,
): Promise<GetAuthenticatorsReturnType> {
  const { projectId, token } = params

  // GET behind StampCheckUser: the backend resolves the user from the stamped
  // credential (+ session JWT), so no body / sub-org is sent. The stamp signs
  // the X-Timestamp value (see transport `stampPostion: 'timestamp'`).
  return await client.request({
    path: `${projectId}/authenticators`,
    method: 'GET',
    headers: {
      Authorization: `Bearer ${token}`,
    },
    stamp: true,
    stampPostion: 'timestamp',
  })
}
