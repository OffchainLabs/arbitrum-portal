import type { PartialBy } from 'viem'
import { SessionType, type ZeroDevWalletSession } from '../types/session.js'

/**
 * Parses a session from a JWT.
 *
 * @param token - The JWT to parse.
 * @returns {PartialBy<ZeroDevWalletSession, "createdAt" | "id" | "stamperType">} - The parsed session.
 */
export function parseSession(
  token: string | ZeroDevWalletSession,
): PartialBy<ZeroDevWalletSession, 'createdAt' | 'id' | 'stamperType'> {
  if (typeof token !== 'string') {
    return token
  }
  const parts = token.split('.')
  if (parts.length !== 3 || !parts[1]) {
    throw new Error('Invalid JWT: Missing payload')
  }

  const base64 = parts[1].replace(/-/g, '+').replace(/_/g, '/')
  const decoded: unknown = JSON.parse(atob(base64))
  if (!decoded || typeof decoded !== 'object') {
    throw new Error('JWT payload missing required fields')
  }
  const {
    exp,
    public_key: publicKey,
    session_type: sessionType,
    user_id: userId,
    organization_id: organizationId,
  } = decoded as Record<string, unknown>

  if (
    typeof exp !== 'number' ||
    !Number.isFinite(exp) ||
    exp <= 0 ||
    typeof publicKey !== 'string' ||
    !publicKey ||
    (sessionType !== SessionType.READ_ONLY &&
      sessionType !== SessionType.READ_WRITE) ||
    typeof userId !== 'string' ||
    !userId ||
    typeof organizationId !== 'string' ||
    !organizationId
  ) {
    throw new Error('JWT payload missing required fields')
  }
  if (normalizeTimestamp(exp) <= Date.now()) {
    throw new Error('JWT session is already expired')
  }

  return {
    sessionType,
    userId,
    organizationId,
    expiry: exp,
    token,
    publicKey,
  }
}

/**
 * Normalizes a timestamp to milliseconds.
 *
 * @param timestamp - The timestamp to normalize.
 * @returns {number} - The normalized timestamp.
 */
export function normalizeTimestamp(timestamp: number): number {
  return timestamp < 1e10 ? timestamp * 1_000 : timestamp
}

/**
 * Generates a random buffer of 32 bytes.
 *
 * @returns {ArrayBuffer} - The random buffer.
 */
export const generateRandomBuffer = (): ArrayBuffer => {
  const arr = new Uint8Array(32)
  crypto.getRandomValues(arr)
  return arr.buffer
}

/**
 * Encodes a challenge in base64url format.
 *
 * @param challenge - The challenge to encode.
 * @returns {string} - The encoded challenge.
 */
export const base64UrlEncode = (challenge: ArrayBuffer): string => {
  const bytes = new Uint8Array(challenge)
  const binary = String.fromCharCode(...bytes)
  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '')
}

/**
 * Compresses an uncompressed P-256 public key into its 33-byte compressed form.
 *
 * @param {Uint8Array} raw - The uncompressed public key (65 bytes, starting with 0x04).
 * @returns {Uint8Array} - The compressed public key (33 bytes, starting with 0x02 or 0x03).
 * @throws {Error} - If the input key is not a valid uncompressed P-256 key.
 */
export function pointEncode(raw: Uint8Array): Uint8Array {
  if (raw.length !== 65 || raw[0] !== 0x04) {
    throw new Error('Invalid uncompressed P-256 key')
  }

  const x = raw.slice(1, 33)
  const y = raw.slice(33, 65)

  if (x.length !== 32 || y.length !== 32) {
    throw new Error('Invalid x or y length')
  }

  const lastY = y.at(-1)
  if (lastY === undefined) throw new Error('Invalid y coordinate')
  const prefix = (lastY & 1) === 0 ? 0x02 : 0x03

  const compressed = new Uint8Array(33)
  compressed[0] = prefix
  compressed.set(x, 1)
  return compressed
}

/**
 * Converts a Uint8Array into a lowercase hex string.
 *
 * @param {Uint8Array} input - The input byte array.
 * @returns {string} - The resulting hex string.
 */
export function uint8ArrayToHexString(input: Uint8Array): string {
  return input.reduce(
    (result, x) => result + x.toString(16).padStart(2, '0'),
    '',
  )
}

/**
 * Generates a compressed public key from a key pair.
 *
 * @returns {Promise<string>} - The compressed public key.
 */
export async function generateCompressedPublicKeyFromKeyPair(
  keyPair: CryptoKeyPair,
): Promise<string> {
  const rawPubKey = new Uint8Array(
    await crypto.subtle.exportKey('raw', keyPair.publicKey),
  )
  const compressedPubKey = pointEncode(rawPubKey)
  const compressedHex = uint8ArrayToHexString(compressedPubKey)
  return compressedHex
}

export const humanReadableDateTime = (): string => {
  return new Date().toLocaleString().replaceAll('/', '-').replaceAll(':', '.')
}
