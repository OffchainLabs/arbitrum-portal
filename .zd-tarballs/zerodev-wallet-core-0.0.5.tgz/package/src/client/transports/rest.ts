import { canonicalizeEx } from 'json-canonicalize'
import { RestRequestError, RestTimeoutError } from '../../errors/request.js'
import type { Stamper } from '../../stampers/types.js'
import type { StamperType } from '../../types/session.js'

export type RestRequestArgs = {
  path: string
  method?: 'GET' | 'POST' | 'PUT' | 'DELETE'
  body?: any
  headers?: Record<string, string>
  stamp?: boolean
  stampWith?: StamperType
  /**
   * Where the stamp goes / what it signs:
   * - `body`/`headers`: sign the canonicalized request body (POST endpoints).
   * - `timestamp`: GET endpoints behind StampCheckUser — sign the current
   *   unix-millis string, send it as the `X-Timestamp` header plus the stamp
   *   header. No request body. Matches the backend's `FormatTimestamp`.
   */
  stampPostion?: 'body' | 'headers' | 'timestamp'
  /** Include credentials (cookies) in the request */
  credentials?: RequestCredentials
}

export type RestRequestFn = <T = any>(args: RestRequestArgs) => Promise<T>

export type RestTransport = {
  config: { key: string; name: string; url: string; timeoutMs: number }
  request: RestRequestFn
  value: Record<string, unknown>
}

export type RestTransportConfig = {
  fetchOptions?: Omit<RequestInit, 'body' | 'method' | 'signal'>
  onRequest?: (
    url: string,
    init: RequestInit,
  ) => Promise<RequestInit | undefined> | RequestInit | undefined
  onResponse?: (res: Response) => Promise<void> | void
  timeoutMs?: number
  key?: string
  name?: string
  apiKeyStamper: Stamper
  passkeyStamper: Stamper
}

export function rest(url: string, cfg: RestTransportConfig): RestTransport {
  const timeoutMs = cfg.timeoutMs ?? 10_000
  const key = cfg.key ?? 'rest'
  const name = cfg.name ?? 'HTTP REST'

  const request: RestRequestFn = async (args) => {
    const fullUrl = `${url}/${args.path}`
    const controller = new AbortController()
    const timer = setTimeout(() => controller.abort(), timeoutMs)

    try {
      let requestBody = args.body
      let requestHeaders: Record<string, string> = {
        ...((cfg.fetchOptions?.headers as Record<string, string>) ?? {}),
        ...(args.headers ?? {}),
        'content-type': 'application/json',
      }

      // Handle stamping if requested
      if (args.stamp) {
        let stamper: Stamper
        if (args.stampWith === 'apiKey') {
          stamper = cfg.apiKeyStamper
        } else if (args.stampWith === 'passkey') {
          stamper = cfg.passkeyStamper
        } else {
          stamper = cfg.apiKeyStamper
        }

        // Timestamped stamp for GET endpoints behind StampCheckUser: the
        // signed body is the unix-millis string itself (the backend rebuilds
        // it from the X-Timestamp header via FormatTimestamp). No request body.
        if (args.stampPostion === 'timestamp') {
          const ts = Date.now().toString()
          const stamp = await stamper.stamp(ts)
          requestHeaders = {
            ...requestHeaders,
            'X-Timestamp': ts,
            [stamp.stampHeaderName]: stamp.stampHeaderValue,
          }
          requestBody = undefined
        } else {
          const { body, apiUrl } = args.body
          const bodyString = canonicalizeEx(body ?? args.body)
          const stamp = await stamper.stamp(bodyString)

          // Restructure request body to match backend expectation
          if (args.stampPostion === 'headers') {
            requestHeaders = {
              ...requestHeaders,
              [stamp.stampHeaderName]: stamp.stampHeaderValue,
            }
          } else if (body) {
            requestBody = {
              body: bodyString,
              stamp: {
                stampHeaderName: stamp.stampHeaderName,
                stampHeaderValue: stamp.stampHeaderValue,
              },
              apiUrl: apiUrl,
            }
          } else {
            requestBody = {
              ...args.body,
              stamp: {
                stampHeaderName: stamp.stampHeaderName,
                stampHeaderValue: stamp.stampHeaderValue,
              },
            }
          }
        }
      }

      const init: RequestInit = {
        ...cfg.fetchOptions,
        method: args.method ?? 'POST',
        headers: requestHeaders,
        body: requestBody != null ? JSON.stringify(requestBody) : null,
        signal: controller.signal,
        ...(args.credentials && { credentials: args.credentials }),
      }

      const finalInit = (await cfg.onRequest?.(fullUrl, init)) ?? init
      const res = await fetch(fullUrl, finalInit)

      await cfg.onResponse?.(res)

      let data: any
      const ct = res.headers.get('content-type') ?? ''
      if (ct.startsWith('application/json')) data = await res.json()
      else {
        const text = await res.text()
        try {
          data = text ? JSON.parse(text) : {}
        } catch {
          data = text
        }
      }

      if (!res.ok) throw new RestRequestError(fullUrl, res.status, data)
      return data as any
    } catch (err: any) {
      if (err.name === 'AbortError') throw new RestTimeoutError(fullUrl)
      throw err
    } finally {
      clearTimeout(timer)
    }
  }

  return {
    config: { key, name, url, timeoutMs },
    request,
    value: {},
  }
}
