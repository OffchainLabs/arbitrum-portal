import { Badge, ListItem, ListItemChevron } from '@zerodev/react-ui'
import { useLayoutEffect } from 'react'
import { useConnectors } from 'wagmi'
import { useAuth } from '../../hooks/useAuth'
import { isZeroDevWalletConnect } from '../../utils/isZeroDevWalletConnect'
import {
  announcesWallet,
  matchesWallet,
  WALLET_GUIDE,
  type WalletId,
} from '../../walletGuide'
import { useSignUpContext } from './context'

/** Dedicated row for a single guide wallet: connects it directly when a live
 * connector claims it, and is a download link for the vendor page otherwise. */
export function SignUpWallet({ walletId }: { walletId: WalletId }) {
  const wallet = WALLET_GUIDE.find((w) => w.id === walletId)
  if (!wallet) {
    // Unreachable for TS consumers; catches raw-JS typos.
    throw new Error(
      `Unknown walletId "${walletId}". Valid ids: ${WALLET_GUIDE.map((w) => w.id).join(', ')}`,
    )
  }

  const { startWalletConnect } = useAuth()
  const { authPending, guardAgreement, registerWallet, openWalletSheet } =
    useSignUpContext()
  const connectors = useConnectors()
  useLayoutEffect(() => registerWallet(wallet.id), [registerWallet, wallet.id])

  // Only a 6963 announcement proves a live extension (or the wallet's own
  // in-app browser) — it earns the badge and a direct connect.
  const announced = connectors.find((c) => announcesWallet(c, wallet))

  const shared = {
    title: wallet.name,
    icon: <img src={wallet.icon} alt="" className="zd:w-6 zd:h-6" />,
    trailing: <ListItemChevron />,
  }

  // An announcement means the wallet is right here (extension, or its own
  // in-app browser) — connect it directly; WC pairing would bounce out of
  // the very wallet the user is standing in.
  if (!announced && connectors.some(isZeroDevWalletConnect)) {
    return (
      <ListItem
        {...shared}
        disabled={authPending}
        onClick={() => {
          if (authPending) return
          if (!guardAgreement()) return
          openWalletSheet(wallet)
        }}
      />
    )
  }

  // Same claim rule as the MoreWallets grid: announced, or — without a WC
  // handoff — a configured connector (e.g. a vendor SDK) that claims the
  // wallet.
  const claimed = announced ?? connectors.find((c) => matchesWallet(c, wallet))

  if (!claimed) {
    return (
      <ListItem {...shared} asChild>
        {/* biome-ignore lint/a11y/useAnchorContent: the row layout (incl. the title text) is injected into the anchor via Slot */}
        <a
          href={wallet.downloadUrl}
          target="_blank"
          rel="noopener noreferrer"
        />
      </ListItem>
    )
  }

  // Hand off to the `wallet-connecting` step, which owns the connect() call.
  const handleClick = () => {
    if (authPending) return
    if (!guardAgreement()) return
    startWalletConnect({
      connectorUid: claimed.uid,
      name: wallet.name,
      icon: wallet.icon,
    })
  }

  return (
    <ListItem
      {...shared}
      {...(!!announced && { subtitle: <Badge text="INSTALLED" /> })}
      disabled={authPending}
      onClick={handleClick}
    />
  )
}
