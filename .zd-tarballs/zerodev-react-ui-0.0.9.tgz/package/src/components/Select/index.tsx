import { Select as SelectPrimitive } from 'radix-ui'
import type { ComponentProps, Ref } from 'react'

import { cn } from '../../utils/common'
import { useZdPortalContainer } from '../../utils/portal'
import { Icon } from '../Icon'
import { Wrapper } from '../Wrapper'

export const Select = SelectPrimitive.Root
export const SelectGroup = SelectPrimitive.Group
export const SelectValue = SelectPrimitive.Value
export const SelectItemText = SelectPrimitive.ItemText

/** Bare styled trigger. Use `asChild` to wrap a custom trigger like `Pill`. */
export function SelectTrigger({
  ref,
  className,
  children,
  ...props
}: ComponentProps<typeof SelectPrimitive.Trigger> & {
  ref?: Ref<HTMLButtonElement>
}) {
  return (
    <SelectPrimitive.Trigger
      ref={ref}
      className={cn(
        // Named group so `SelectIcon` can read THIS trigger's open state.
        'zd:group/select',
        'zd:inline-flex zd:items-center zd:justify-between zd:gap-2',
        'zd:outline-none zd:cursor-pointer',
        // Counters Radix's `pointer-events: none` on the trigger while the
        // panel is open — without this the trigger goes inert and can't be
        // clicked to toggle closed.
        'zd:data-[state=open]:pointer-events-auto',
        'zd:disabled:cursor-not-allowed zd:disabled:opacity-50',
        className,
      )}
      {...props}
    >
      {children}
    </SelectPrimitive.Trigger>
  )
}

/** Trigger affordance slot. Defaults to a chevronDown icon. */
export function SelectIcon({
  ref,
  className,
  children,
  ...props
}: ComponentProps<typeof SelectPrimitive.Icon> & {
  ref?: Ref<HTMLSpanElement>
}) {
  return (
    <SelectPrimitive.Icon
      ref={ref}
      // Turns to face up while the panel is open, animated both ways. Scoped
      // to the trigger's own group, not any open ancestor: a Select rendered
      // inside a BottomSheet would otherwise sit permanently flipped, since
      // Radix marks the open dialog content with the same `data-state`.
      className={cn(
        'zd:shrink-0 zd:transition-transform zd:duration-200',
        'zd:group-data-[state=open]/select:rotate-180',
        className,
      )}
      {...props}
    >
      {children ?? (
        <Icon name="chevronDown" className="zd:size-4 zd:text-greyScale" />
      )}
    </SelectPrimitive.Icon>
  )
}

/** Portaled popper panel. Width defaults to `--radix-select-trigger-width`;
 * override via inline `style={{ width }}`. */
export function SelectContent({
  ref,
  className,
  children,
  position = 'popper',
  sideOffset = 8,
  style,
  ...props
}: ComponentProps<typeof SelectPrimitive.Content> & {
  ref?: Ref<HTMLDivElement>
}) {
  const portalContainer = useZdPortalContainer()
  return (
    <SelectPrimitive.Portal container={portalContainer}>
      <SelectPrimitive.Content
        ref={ref}
        position={position}
        sideOffset={sideOffset}
        className={cn(
          'zd:z-50 zd:max-h-80 zd:outline-none',
          'zd:data-[state=open]:animate-popper-in',
          className,
        )}
        {...props}
        style={{
          width: 'var(--radix-select-trigger-width)',
          transformOrigin: 'var(--radix-select-content-transform-origin)',
          ...style,
        }}
      >
        <Wrapper
          variant="solid"
          // Override Wrapper's 80% white translucency — a dropdown over
          // content shouldn't let the content bleed through.
          style={{ backgroundColor: '#fff' }}
          className="zd:flex zd:flex-col zd:rounded-2xl zd:overflow-hidden"
        >
          <SelectPrimitive.Viewport className="zd:overflow-y-auto zd:max-h-80">
            {children}
          </SelectPrimitive.Viewport>
        </Wrapper>
      </SelectPrimitive.Content>
    </SelectPrimitive.Portal>
  )
}

/** Option row. Children render as-is; set `textValue` for typeahead when
 * children aren't plain text. */
export function SelectItem({
  ref,
  className,
  children,
  ...props
}: ComponentProps<typeof SelectPrimitive.Item> & {
  ref?: Ref<HTMLDivElement>
}) {
  return (
    <SelectPrimitive.Item
      ref={ref}
      className={cn(
        // Default padding for plain-text items. Complex children with their
        // own padding (e.g. `<TokenListItem>`) opt out via `className="zd:p-0"`.
        'zd:relative zd:outline-none zd:cursor-pointer zd:px-3 zd:py-2',
        'zd:data-[highlighted]:bg-offWhite/40',
        'zd:data-[state=checked]:bg-offWhite/60',
        className,
      )}
      {...props}
    >
      {children}
    </SelectPrimitive.Item>
  )
}

export function SelectSeparator({
  ref,
  className,
  ...props
}: ComponentProps<typeof SelectPrimitive.Separator> & {
  ref?: Ref<HTMLDivElement>
}) {
  return (
    <SelectPrimitive.Separator
      ref={ref}
      className={cn('zd:h-px zd:bg-offWhite/50 zd:mx-2 zd:my-1', className)}
      {...props}
    />
  )
}
