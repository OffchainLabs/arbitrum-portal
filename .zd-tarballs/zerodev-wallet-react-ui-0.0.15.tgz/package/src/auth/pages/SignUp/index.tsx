import { Button, Text } from '@zerodev/react-ui'
import { type ReactNode, useCallback, useState } from 'react'
import { SignUpFooter } from '../../../shared/components/SignUpFooter'
import { WalletSheet } from '../../components/WalletSheet'
import { useWalletConnectPairing } from '../../hooks/useWalletConnectPairing'
import type { EmailAuthMethod } from '../../types'
import type { WalletGuideEntry } from '../../walletGuide'
import { SignUpContext } from './context'
import { SignUpEmail } from './Email'
import { SignUpGoogle } from './Google'
import { SignUpInstalledWallets } from './InstalledWallets'
import { SignUpMoreWallets } from './MoreWallets'
import { SignUpPasskey } from './Passkey'
import {
  SignUpSolanaWalletConnect,
  SolanaWalletConnectSheet,
} from './SolanaWalletConnect'
import { SignUpWallet } from './Wallet'
import { SignUpWalletConnect } from './WalletConnect'

type SignUpRootProps = {
  children: ReactNode
  /** Enable the consent gate: linked from the footer checkbox, and every
   * method is blocked until the user agrees when either URL is set. */
  termsAndConditionsUrl?: string | undefined
  privacyPolicyUrl?: string | undefined
  /** Which email verification flow the Email unit runs. */
  emailAuthMethod?: EmailAuthMethod | undefined
}

function SignUpRoot({
  children,
  termsAndConditionsUrl,
  privacyPolicyUrl,
  emailAuthMethod = 'magicLink',
}: SignUpRootProps) {
  const [agreedToTerms, setAgreedToTerms] = useState(false)
  const [highlightAgreement, setHighlightAgreement] = useState(false)
  const [error, setError] = useState<string | null>(null)
  // One flag for the whole page: methods are mutually exclusive, so at most
  // one unit is in flight at a time. Known accepted edge: a unit unmounting
  // mid-flight (conditional composition) clears a sibling's lock.
  const [authPending, setAuthPending] = useState(false)
  // Which wallets have a pinned `SignUp.Wallet` row mounted. A plain list of
  // registrants: register appends, cleanup removes one occurrence.
  const [registeredWallets, setRegisteredWallets] = useState<readonly string[]>(
    [],
  )

  const registerWallet = useCallback((walletId: string) => {
    setRegisteredWallets((prev) => [...prev, walletId])
    return () => {
      setRegisteredWallets((prev) => {
        const next = [...prev]
        next.splice(next.indexOf(walletId), 1)
        return next
      })
    }
  }, [])

  // The page's single WalletSheet — every wallet surface opens it via
  // `openWalletSheet` instead of mounting a sheet of its own. The box
  // distinguishes open-without-a-wallet (generic pairing) from closed.
  const [walletSheet, setWalletSheet] = useState<{
    wallet?: WalletGuideEntry | undefined
  } | null>(null)
  // Pairing preloads at page mount so the sheet's QR is ready on open and the
  // mobile deep link below fires synchronously inside the tap — iOS only
  // hands a universal link to the app for gesture-qualified navigations.
  const pairing = useWalletConnectPairing()
  // The Solana pairing is proposed only while its sheet is open (no deep
  // links to arm synchronously), so it is not preloaded like the EVM one;
  // the sheet itself stays mounted so it animates closed.
  const [solanaSheetOpen, setSolanaSheetOpen] = useState(false)

  const requiresAgreement = !!(termsAndConditionsUrl || privacyPolicyUrl)
  const needsAgreement = requiresAgreement && !agreedToTerms

  const guardAgreement = () => {
    if (!needsAgreement) return true
    setHighlightAgreement(true)
    return false
  }

  return (
    <SignUpContext.Provider
      value={{
        authPending,
        emailAuthMethod,
        setAuthPending,
        needsAgreement,
        guardAgreement,
        setError,
        registeredWallets,
        registerWallet,
        openWalletSheet: (wallet) => {
          const deepLink = wallet && pairing.deepLinkFor(wallet)
          if (deepLink) window.location.href = deepLink
          // Sheet opens either way — it's the fallback surface when the
          // redirect doesn't take (and the only surface on desktop).
          setWalletSheet({ wallet })
        },
        openSolanaWalletSheet: () => setSolanaSheetOpen(true),
      }}
    >
      {error !== null && (
        <div className="zd:flex zd:items-center zd:justify-center zd:h-full zd:min-h-100">
          <div className="zd:flex zd:flex-col zd:gap-4 zd:max-w-md">
            <Text className="zd:text-h2 zd:text-center">Error occurred</Text>
            <Text className="zd:text-center zd:text-error-primary">
              {error}
            </Text>
            <Button
              action="primary"
              text="Try again"
              onClick={() => setError(null)}
            />
          </div>
        </div>
      )}
      {/* Kept mounted (hidden) during the error takeover so unit state — the
          typed email, pending flags — survives "Try again".
          `-mx-4` cancels Screen's scroll-container padding so this page
          owns its own; inner blocks re-add `zd:px-4` where they need it. */}
      <div
        className={`zd:-mx-4 zd:flex-1 zd:flex zd:flex-col zd:justify-between zd:pb-4 zd:overflow-y-auto zd:overflow-x-hidden${
          error !== null ? ' zd:hidden' : ''
        }`}
      >
        <div className="zd:flex-1 zd:flex zd:flex-col zd:justify-center">
          <div className="zd:px-4 zd:flex zd:flex-col zd:items-center">
            <Text className="zd:text-h2 zd:text-center">
              Continue to your wallet
            </Text>
            <Text className="zd:mt-2 zd:text-center zd:text-neutral-secondary">
              Choose a sign-in method to proceed
            </Text>
          </div>
          <div className="zd:mt-6 zd:mb-4 zd:px-4 zd:flex zd:flex-col zd:gap-2">
            {children}
          </div>
        </div>
        <div className="zd:px-4">
          <SignUpFooter
            termsAndConditionsUrl={termsAndConditionsUrl}
            privacyPolicyUrl={privacyPolicyUrl}
            agreedToTerms={agreedToTerms}
            setAgreedToTerms={(agreed) => {
              setAgreedToTerms(agreed)
              if (agreed) setHighlightAgreement(false)
            }}
            highlight={highlightAgreement}
          />
        </div>
      </div>
      <WalletSheet
        pairing={pairing}
        open={walletSheet !== null}
        onOpenChange={(open) => {
          if (!open) setWalletSheet(null)
        }}
        wallet={walletSheet?.wallet}
      />
      <SolanaWalletConnectSheet
        open={solanaSheetOpen}
        onOpenChange={setSolanaSheetOpen}
      />
    </SignUpContext.Provider>
  )
}

function SignUpDivider({ label = 'or' }: { label?: string }) {
  return (
    <div className="zd:-mx-4 zd:my-2 zd:flex zd:items-center zd:gap-3">
      <div className="zd:flex-1 zd:border-t zd:border-inverse-secondary" />
      <Text className="zd:text-body3">{label}</Text>
      <div className="zd:flex-1 zd:border-t zd:border-inverse-secondary" />
    </div>
  )
}

/** The canonical sign-up page. Takes the root's own props (the consent-gate
 * URLs) and forwards them — per-unit config (e.g. the email method) still
 * means composing the units yourself. */
function SignUpDefault(props: Omit<SignUpRootProps, 'children'>) {
  return (
    <SignUpRoot {...props}>
      <SignUpPasskey />
      <SignUpDivider />
      <SignUpGoogle />
      <SignUpEmail />
    </SignUpRoot>
  )
}

export const SignUp = Object.assign(SignUpRoot, {
  Default: SignUpDefault,
  Passkey: SignUpPasskey,
  Google: SignUpGoogle,
  Email: SignUpEmail,
  Wallet: SignUpWallet,
  WalletConnect: SignUpWalletConnect,
  InstalledWallets: SignUpInstalledWallets,
  SolanaWalletConnect: SignUpSolanaWalletConnect,
  MoreWallets: SignUpMoreWallets,
  Divider: SignUpDivider,
})
